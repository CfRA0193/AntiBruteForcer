﻿using System.Reflection;

[assembly: AssemblyTitle("Scrypt.NET")]
[assembly: AssemblyDescription("A .NET implementation of scrypt algorithm.")]
[assembly: AssemblyCompany("Vinicius Chiele")]
[assembly: AssemblyProduct("Scrypt.NET")]
[assembly: AssemblyCopyright("Copyright © Vinicius Chiele 2014")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0.0")]